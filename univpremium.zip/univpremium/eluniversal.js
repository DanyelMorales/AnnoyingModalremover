let htmlElement = document.querySelector("html");
let modalElement = document.querySelector("#piano_wrapper");
htmlElement.setAttribute("style", "overflow:scroll !important;");
modalElement.remove();